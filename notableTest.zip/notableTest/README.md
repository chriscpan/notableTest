# Welcome!

## Getting Started

### Prerequisites
* Node version > 6 (preferred through [Node Version Manager](https://github.com/creationix/nvm))

### Installing the application

* git clone
* `npm install`

### Running the application
* `node ./index.js`
* The server is now running on [localhost:3000](http://localhost:3000/)

### Testing

* Didn't get to this yet
