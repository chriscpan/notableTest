const physicians = [
	{ id: 1,
	  firstName: 'Julius',
	  lastName: 'Hibbert'
	},
	{
	  id: 2,
	  firstName: 'Algernop',
	  lastName: 'Kriegar'
	},
	{
	  id: 3,
	  firstName: 'Nick',
	  lastName: 'Riviera'
	}
];

module.exports = physicians;